-- NUKEVIET 3.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: March 4, 2016, 10:49 AM GMT
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `download`
--


-- ---------------------------------------


--
-- Table structure for table `nv3_authors`
--

DROP TABLE IF EXISTS `nv3_authors`;
CREATE TABLE `nv3_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_authors`
--

INSERT INTO `nv3_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'b39b2e6b1f5982a97f0483e23c50bfa978d27252', 1457088549, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:44.0) Gecko/20100101 Firefox/44.0');


-- ---------------------------------------


--
-- Table structure for table `nv3_authors_config`
--

DROP TABLE IF EXISTS `nv3_authors_config`;
CREATE TABLE `nv3_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banip`
--

DROP TABLE IF EXISTS `nv3_banip`;
CREATE TABLE `nv3_banip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_click`
--

DROP TABLE IF EXISTS `nv3_banners_click`;
CREATE TABLE `nv3_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_clients`
--

DROP TABLE IF EXISTS `nv3_banners_clients`;
CREATE TABLE `nv3_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_plans`
--

DROP TABLE IF EXISTS `nv3_banners_plans`;
CREATE TABLE `nv3_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_banners_plans`
--

INSERT INTO `nv3_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_rows`
--

DROP TABLE IF EXISTS `nv3_banners_rows`;
CREATE TABLE `nv3_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_banners_rows`
--

INSERT INTO `nv3_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', 'http://www.mofa.gov.vn', '', '', '', 1457088459, 1457088459, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', 'http://vinades.vn', '', '', '', 1457088459, 1457088459, 0, 0, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', 'http://webnhanh.vn', '', '', '', 1457088459, 1457088459, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_config`
--

DROP TABLE IF EXISTS `nv3_config`;
CREATE TABLE `nv3_config` (
  `lang` char(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_config`
--

INSERT INTO `nv3_config` VALUES
('sys', 'global', 'closed_site', '0'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'site_lang', 'en'), 
('sys', 'global', 'admin_theme', 'admin_full'), 
('sys', 'global', 'date_pattern', 'l, d-m-Y'), 
('sys', 'global', 'time_pattern', 'H:i'), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'online_upd', '1'), 
('sys', 'global', 'statistic', '1'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'strong'), 
('sys', 'global', 'upload_logo', 'images/logo.png'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'getloadavg', '0'), 
('sys', 'global', 'mailer_mode', ''), 
('sys', 'global', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'global', 'smtp_ssl', '1'), 
('sys', 'global', 'smtp_port', '465'), 
('sys', 'global', 'smtp_username', 'user@gmail.com'), 
('sys', 'global', 'smtp_password', 'userpass'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '1'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'en'), 
('sys', 'global', 'allow_adminlangs', 'cs,en,fr,tr,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'is_url_rewrite', '1'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autologomod', ''), 
('sys', 'global', 'autologosize1', '50'), 
('sys', 'global', 'autologosize2', '40'), 
('sys', 'global', 'autologosize3', '30'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google,myopenid'), 
('sys', 'global', 'optActive', '1'), 
('sys', 'global', 'timestamp', '1'), 
('sys', 'global', 'googleAnalyticsID', ''), 
('sys', 'global', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'global', 'searchEngineUniqueID', ''), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'revision', '1950'), 
('sys', 'global', 'version', '3.4.03'), 
('sys', 'global', 'whoviewuser', '2'), 
('en', 'global', 'site_name', 'gamepro69'), 
('en', 'global', 'site_logo', 'images/logo.png'), 
('en', 'global', 'site_description', 'NukeViet CMS 3.x Developed by VINADES.,JSC'), 
('en', 'global', 'site_keywords', ''), 
('en', 'global', 'site_theme', 'modern'), 
('en', 'global', 'site_home_module', 'news'), 
('en', 'global', 'switch_mobi_des', '1'), 
('en', 'global', 'disable_site_content', 'For technical reasons Web site temporary not available. we are very sorry for that inconvenience!'), 
('en', 'news', 'indexfile', 'viewcat_main_right'), 
('en', 'news', 'per_page', '20'), 
('en', 'news', 'st_links', '10'), 
('en', 'news', 'auto_postcomm', '1'), 
('en', 'news', 'homewidth', '100'), 
('en', 'news', 'homeheight', '150'), 
('en', 'news', 'blockwidth', '52'), 
('en', 'news', 'blockheight', '75'), 
('en', 'news', 'imagefull', '460'), 
('en', 'news', 'setcomm', '2'), 
('en', 'news', 'copyright', 'Note: The above article reprinted at the website or other media sources not specify the source http://nukeviet.vn is copyright infringement'), 
('en', 'news', 'showhometext', '1'), 
('en', 'news', 'activecomm', '1'), 
('en', 'news', 'emailcomm', '1'), 
('en', 'news', 'timecheckstatus', '0'), 
('en', 'news', 'config_source', '0'), 
('sys', 'global', 'site_email', 'tungfpm@outlook.com'), 
('sys', 'global', 'error_send_email', 'tungfpm@outlook.com'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv3c_J89ju'), 
('sys', 'global', 'session_prefix', 'nv3s_Ciqwe7'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', ''), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0');


-- ---------------------------------------


--
-- Table structure for table `nv3_cronjobs`
--

DROP TABLE IF EXISTS `nv3_cronjobs`;
CREATE TABLE `nv3_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `interval` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `en_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_cronjobs`
--

INSERT INTO `nv3_cronjobs` VALUES
(1, 1457088459, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1457088552, 1, 'De-lete expired online status'), 
(2, 1457088459, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 0, 0, 'Automatic backup database'), 
(3, 1457088459, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 0, 0, 'Empty temporary files'), 
(4, 1457088459, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 0, 0, 'De-lete IP log files'), 
(5, 1457088459, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 0, 0, 'De-lete expired error_log log files'), 
(6, 1457088459, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Send error logs to admin'), 
(7, 1457088459, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 0, 0, 'De-lete expired referer'), 
(8, 1457088459, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 1, 1, 0, 0, 'Up-date site diagnostic'), 
(9, 1457088459, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 0, 0, 'Check NukeViet version');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_about`
--

DROP TABLE IF EXISTS `nv3_en_about`;
CREATE TABLE `nv3_en_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_about`
--

INSERT INTO `nv3_en_about` VALUES
(1, 'Welcome to NukeViet 3.0', 'Welcome-to-NukeViet-3-0', '<p> NukeViet developed by Vietnamese and for Vietnamese. It&#039;s the 1st opensource CMS in Vietnam. Next generation of NukeViet, version 3.0 coding ground up. Support newest web technology, include xHTML, CSS 3, XTemplate, jQuery, AJAX...<br  /> <br  /> NukeViet&#039;s has it own core libraries build in. So, it&#039;s doesn&#039;t depend on other exists frameworks. With basic knowledge of PHP and MySQL, you can easily using NukeViet for your purposes.<br  /> <br  /> NukeViet 3 core is simply but powerful. It support modules can be multiply. We called it abstract modules. It help users automatic crea-te many modules without any line of code from any exists module which support crea-te abstract modules.<br  /> <br  /> NukeViet 3 support automatic setup modules, blocks, themes at Admin Control Panel. It&#039;s also allow you to share your modules by packed it into packets.<br  /> <br  /> NukeViet 3 support multi languages in 2 types. Multi interface languages and multi database langguages. Had features support web master to build new languages. Many advance features still developing. Let use it, distribute it and feel about opensource.<br  /> <br  /> At last, NukeViet 3 is a thanksgiving gift from VINADES.,JSC to community for all of your supports. And we hoping we going to be a biggest opensource CMS not only in VietNam, but also in the world. :).<br  /> <br  /> If you had any feedbacks and ideas for NukeViet 3 close beta. Feel free to send email to admin@nukeviet.vn. All are welcome<br  /> <br  /> Best regard.</p>', '', 1, 1, 1277266815, 1277266815, 1), 
(2, 'NukeViet&#039;s versioning schemes', 'NukeViet-s-versioning-schemes', '<p> NukeViet using 2 versioning schemes:<br  /> <br  /> I. By numbers (technical purposes):<br  /> Structure for numbers is:<br  /> major.minor.revision<br  /> <br  /> 1.Major: Major up-date. Probably not backwards compatible with older version.<br  /> 2.Minor: Minor change, may introduce new features, but backwards compatibility is mostly retained.<br  /> 3.Revision: Minor bug fixes. Packed for testing or pre-release purposes... Closed beta, open beta, RC, Official release.<br  /> <br  /> II: By names (new version release management)<br  /> Main milestones: Closed beta, Open beta, Release candidate, Official.<br  /> 1. Closed beta: Limited testing.<br  /> characteristics: New features testing. It may not include in official version if doesn&#039;t accord with community. Closed beta&#039;s name can contain unique numbers. Ex: Closed beta 1, closed beta 2,... Features of previous release may not include in it&#039;s next release. Time release is announced by development team. This milestone stop when system haven&#039;t any major changes.<br  /> Purposes: Pre-release version to receive feedbacks and ideas from community. Bug fixes for release version.<br  /> Release to: Programmers, expert users.<br  /> Supports:<br  /> &nbsp;&nbsp;&nbsp; Using: None.<br  /> &nbsp;&nbsp;&nbsp; Testing: Documents, not include manual.<br  /> Upgrade: None.<br  /> <br  /> 2. Open beta: Public testing.<br  /> characteristics: Features testing, contain full features of official version. It&#039;s almost include in official version even if it doesn&#039;t accord with community. This milestone start after closed beta milestone closed and release weekly to fix bugs. Open beta&#039;s name can contain unique numbers. Ex: Open beta 1, open beta 2,... Next release include all features of it&#039;s previous release. Open beta milestone stop when system haven&#039;t any critical issue.<br  /> Purposes: Bug fixed which not detect in closed beta.<br  /> Release to: All users of nukeviet.vn forum.<br  /> Supports:<br  /> &nbsp;&nbsp;&nbsp; Using: Limited. Manual and forum supports.<br  /> &nbsp;&nbsp;&nbsp; Testing: Full.<br  /> Upgrade: None.<br  /> <br  /> 3. Release Candidate:<br  /> characteristics: Most stable version and prepare for official release. Release candidate&#039;s name can contain unique numbers.<br  /> Ex: RC 1, RC 2,... by released number.<br  /> If detect cretical issue in this milestone. Another Release Candidate version can be release sooner than release time announced by development team.<br  /> Purposes: Reduce bugs of using official version.<br  /> Release to: All people.<br  /> Supports: Full.<br  /> Upgrade: Yes.<br  /> <br  /> 4. Official:<br  /> characteristics: 1st stable release of new version. It only using 1 time. Next release using numbers. Release about 2 weeks after Release Candidate milestone stoped.<br  /> Purposes: Stop testing and recommend users using new version.</p>', '', 2, 1, 1277267054, 1277693688, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_blocks_groups`
--

DROP TABLE IF EXISTS `nv3_en_blocks_groups`;
CREATE TABLE `nv3_en_blocks_groups` (
  `bid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=21  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_blocks_groups`
--

INSERT INTO `nv3_en_blocks_groups` VALUES
(1, 'default', 'news', 'global.block_category.php', 'Menu', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:\"title_length\";i:25;}'), 
(2, 'default', 'statistics', 'global.counter.php', 'Counter', '', '', '[LEFT]', 0, 1, '0', 1, 2, ''), 
(3, 'default', 'banners', 'global.banners.php', 'Left Banner', '', '', '[LEFT]', 0, 1, '0', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(4, 'default', 'about', 'global.about.php', 'About', '', 'orange', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(5, 'default', 'users', 'global.login.php', 'Login site', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(6, 'default', 'voting', 'global.voting_random.php', 'Voting', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(7, 'default', 'news', 'module.block_headline.php', 'headline', '', 'no_title', '[TOP]', 0, 1, '0', 0, 1, ''), 
(8, 'default', 'banners', 'global.banners.php', 'Center Banner', '', 'no_title', '[TOP]', 0, 1, '0', 1, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(9, 'modern', 'news', 'module.block_newscenter.php', 'News Center', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 1, ''), 
(10, 'modern', 'about', 'global.about.php', 'About', '', 'no_title_html', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Login site', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Voting', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Counter', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '0', 0, 5, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Top banner', '', 'no_title', '[TOPADV]', 0, 1, '0', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.menu_theme_modern.php', 'global menu theme modern', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(17, 'default', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(18, 'modern', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:207:\"© Copyright NukeViet 3. All right reserved.<br  />Powered by <a href=\"http://nukeviet.vn/\" title=\"NukeViet CMS\">NukeViet CMS</a>. Design by <a href=\"http://vinades.vn/\" title=\"VINADES.,JSC\">VINADES.,JSC</a>\";}'), 
(19, 'default', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:231:\"<p class=\"footer\"> © Copyright NukeViet 3. All right reserved.</p><p> Powered by <a href=\"http://nukeviet.vn/\" title=\"NukeViet CMS\">NukeViet CMS</a>. Design by <a href=\"http://vinades.vn/\" title=\"VINADES.,JSC\">VINADES.,JSC</a></p>\";}'), 
(20, 'mobile_nukeviet', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_blocks_weight`
--

DROP TABLE IF EXISTS `nv3_en_blocks_weight`;
CREATE TABLE `nv3_en_blocks_weight` (
  `bid` int(11) NOT NULL DEFAULT '0',
  `func_id` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_blocks_weight`
--

INSERT INTO `nv3_en_blocks_weight` VALUES
(1, 5, 1), 
(1, 6, 1), 
(1, 7, 1), 
(1, 13, 1), 
(1, 15, 1), 
(1, 16, 1), 
(2, 2, 1), 
(2, 36, 1), 
(2, 39, 1), 
(2, 42, 1), 
(2, 43, 1), 
(2, 27, 1), 
(2, 5, 2), 
(2, 6, 2), 
(2, 7, 2), 
(2, 13, 2), 
(2, 15, 2), 
(2, 16, 2), 
(2, 47, 1), 
(2, 46, 1), 
(2, 28, 1), 
(2, 29, 1), 
(2, 30, 1), 
(2, 31, 1), 
(2, 32, 1), 
(2, 33, 1), 
(2, 34, 1), 
(2, 17, 1), 
(2, 25, 1), 
(2, 24, 1), 
(2, 23, 1), 
(2, 22, 1), 
(2, 21, 1), 
(2, 20, 1), 
(2, 19, 1), 
(2, 18, 1), 
(2, 26, 1), 
(3, 2, 2), 
(3, 36, 2), 
(3, 39, 2), 
(3, 42, 2), 
(3, 43, 2), 
(3, 27, 2), 
(3, 5, 3), 
(3, 6, 3), 
(3, 7, 3), 
(3, 13, 3), 
(3, 15, 3), 
(3, 16, 3), 
(3, 47, 2), 
(3, 46, 2), 
(3, 28, 2), 
(3, 29, 2), 
(3, 30, 2), 
(3, 31, 2), 
(3, 32, 2), 
(3, 33, 2), 
(3, 34, 2), 
(3, 17, 2), 
(3, 25, 2), 
(3, 24, 2), 
(3, 23, 2), 
(3, 22, 2), 
(3, 21, 2), 
(3, 20, 2), 
(3, 19, 2), 
(3, 18, 2), 
(3, 26, 2), 
(4, 2, 1), 
(4, 36, 1), 
(4, 39, 1), 
(4, 42, 1), 
(4, 43, 1), 
(4, 27, 1), 
(4, 5, 1), 
(4, 6, 1), 
(4, 7, 1), 
(4, 13, 1), 
(4, 15, 1), 
(4, 16, 1), 
(4, 47, 1), 
(4, 46, 1), 
(4, 28, 1), 
(4, 29, 1), 
(4, 30, 1), 
(4, 31, 1), 
(4, 32, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 17, 1), 
(4, 25, 1), 
(4, 24, 1), 
(4, 23, 1), 
(4, 22, 1), 
(4, 21, 1), 
(4, 20, 1), 
(4, 19, 1), 
(4, 18, 1), 
(4, 26, 1), 
(5, 2, 2), 
(5, 36, 2), 
(5, 39, 2), 
(5, 42, 2), 
(5, 43, 2), 
(5, 27, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 13, 2), 
(5, 15, 2), 
(5, 16, 2), 
(5, 47, 2), 
(5, 46, 2), 
(5, 28, 2), 
(5, 29, 2), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 17, 2), 
(5, 25, 2), 
(5, 24, 2), 
(5, 23, 2), 
(5, 22, 2), 
(5, 21, 2), 
(5, 20, 2), 
(5, 19, 2), 
(5, 18, 2), 
(5, 26, 2), 
(6, 2, 3), 
(6, 36, 3), 
(6, 39, 3), 
(6, 42, 3), 
(6, 43, 3), 
(6, 27, 3), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 13, 3), 
(6, 15, 3), 
(6, 16, 3), 
(6, 47, 3), 
(6, 46, 3), 
(6, 28, 3), 
(6, 29, 3), 
(6, 30, 3), 
(6, 31, 3), 
(6, 32, 3), 
(6, 33, 3), 
(6, 34, 3), 
(6, 17, 3), 
(6, 25, 3), 
(6, 24, 3), 
(6, 23, 3), 
(6, 22, 3), 
(6, 21, 3), 
(6, 20, 3), 
(6, 19, 3), 
(6, 18, 3), 
(6, 26, 3), 
(7, 7, 1), 
(8, 2, 1), 
(8, 36, 1), 
(8, 39, 1), 
(8, 42, 1), 
(8, 43, 1), 
(8, 27, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 2), 
(8, 13, 1), 
(8, 15, 1), 
(8, 16, 1), 
(8, 47, 1), 
(8, 46, 1), 
(8, 28, 1), 
(8, 29, 1), 
(8, 30, 1), 
(8, 31, 1), 
(8, 32, 1), 
(8, 33, 1), 
(8, 34, 1), 
(8, 17, 1), 
(8, 25, 1), 
(8, 24, 1), 
(8, 23, 1), 
(8, 22, 1), 
(8, 21, 1), 
(8, 20, 1), 
(8, 19, 1), 
(8, 18, 1), 
(8, 26, 1), 
(9, 7, 1), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 27, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 47, 1), 
(10, 46, 1), 
(10, 28, 1), 
(10, 29, 1), 
(10, 30, 1), 
(10, 31, 1), 
(10, 32, 1), 
(10, 33, 1), 
(10, 34, 1), 
(10, 17, 1), 
(10, 25, 1), 
(10, 24, 1), 
(10, 23, 1), 
(10, 22, 1), 
(10, 21, 1), 
(10, 20, 1), 
(10, 19, 1), 
(10, 18, 1), 
(10, 26, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 27, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 47, 2), 
(11, 46, 2), 
(11, 28, 2), 
(11, 29, 2), 
(11, 30, 2), 
(11, 31, 2), 
(11, 32, 2), 
(11, 33, 2), 
(11, 34, 2), 
(11, 17, 2), 
(11, 25, 2), 
(11, 24, 2), 
(11, 23, 2), 
(11, 22, 2), 
(11, 21, 2), 
(11, 20, 2), 
(11, 19, 2), 
(11, 18, 2), 
(11, 26, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 27, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 47, 3), 
(12, 46, 3), 
(12, 28, 3), 
(12, 29, 3), 
(12, 30, 3), 
(12, 31, 3), 
(12, 32, 3), 
(12, 33, 3), 
(12, 34, 3), 
(12, 17, 3), 
(12, 25, 3), 
(12, 24, 3), 
(12, 23, 3), 
(12, 22, 3), 
(12, 21, 3), 
(12, 20, 3), 
(12, 19, 3), 
(12, 18, 3), 
(12, 26, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 27, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 47, 4), 
(13, 46, 4), 
(13, 28, 4), 
(13, 29, 4), 
(13, 30, 4), 
(13, 31, 4), 
(13, 32, 4), 
(13, 33, 4), 
(13, 34, 4), 
(13, 17, 4), 
(13, 25, 4), 
(13, 24, 4), 
(13, 23, 4), 
(13, 22, 4), 
(13, 21, 4), 
(13, 20, 4), 
(13, 19, 4), 
(13, 18, 4), 
(13, 26, 4), 
(14, 5, 5), 
(14, 6, 5), 
(14, 7, 5), 
(14, 13, 5), 
(14, 15, 5), 
(14, 16, 5), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 27, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 47, 1), 
(15, 46, 1), 
(15, 28, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 17, 1), 
(15, 25, 1), 
(15, 24, 1), 
(15, 23, 1), 
(15, 22, 1), 
(15, 21, 1), 
(15, 20, 1), 
(15, 19, 1), 
(15, 18, 1), 
(15, 26, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 27, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 47, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 27, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 47, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 27, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 47, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(19, 2, 1), 
(19, 36, 1), 
(19, 39, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 27, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 13, 1), 
(19, 15, 1), 
(19, 16, 1), 
(19, 47, 1), 
(19, 46, 1), 
(19, 33, 1), 
(19, 32, 1), 
(19, 30, 1), 
(19, 29, 1), 
(19, 31, 1), 
(19, 28, 1), 
(19, 34, 1), 
(19, 24, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 26, 1), 
(19, 23, 1), 
(19, 18, 1), 
(19, 25, 1), 
(19, 17, 1), 
(19, 22, 1), 
(19, 19, 1), 
(19, 48, 1), 
(2, 48, 1), 
(3, 48, 2), 
(17, 48, 1), 
(4, 48, 1), 
(5, 48, 2), 
(6, 48, 3), 
(8, 48, 1), 
(18, 48, 1), 
(16, 48, 1), 
(10, 48, 1), 
(11, 48, 2), 
(12, 48, 3), 
(13, 48, 4), 
(15, 48, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 27, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 47, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 48, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(16, 35, 1), 
(10, 35, 1), 
(11, 35, 2), 
(12, 35, 3), 
(13, 35, 4), 
(15, 35, 1), 
(18, 35, 1), 
(17, 35, 1), 
(19, 35, 1), 
(2, 35, 1), 
(3, 35, 2), 
(4, 35, 1), 
(5, 35, 2), 
(6, 35, 3), 
(8, 35, 1), 
(20, 35, 1), 
(16, 50, 1), 
(10, 50, 1), 
(11, 50, 2), 
(12, 50, 3), 
(13, 50, 4), 
(15, 50, 1), 
(18, 50, 1), 
(17, 50, 1), 
(19, 50, 1), 
(2, 50, 1), 
(3, 50, 2), 
(4, 50, 1), 
(5, 50, 2), 
(6, 50, 3), 
(8, 50, 1), 
(20, 50, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_contact_rows`
--

DROP TABLE IF EXISTS `nv3_en_contact_rows`;
CREATE TABLE `nv3_en_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_contact_rows`
--

INSERT INTO `nv3_en_contact_rows` VALUES
(1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_contact_send`
--

DROP TABLE IF EXISTS `nv3_en_contact_send`;
CREATE TABLE `nv3_en_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_counter`
--

DROP TABLE IF EXISTS `nv3_en_counter`;
CREATE TABLE `nv3_en_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_counter`
--

INSERT INTO `nv3_en_counter` VALUES
('c_time', 'start', 0, 0), 
('c_time', 'last', 0, 0), 
('total', 'hits', 0, 0), 
('year', '2009', 0, 0), 
('year', '2010', 0, 0), 
('year', '2011', 0, 0), 
('year', '2012', 0, 0), 
('year', '2013', 0, 0), 
('year', '2014', 0, 0), 
('year', '2015', 0, 0), 
('year', '2016', 0, 0), 
('year', '2017', 0, 0), 
('year', '2018', 0, 0), 
('year', '2019', 0, 0), 
('year', '2020', 0, 0), 
('month', 'Jan', 0, 0), 
('month', 'Feb', 0, 0), 
('month', 'Mar', 0, 0), 
('month', 'Apr', 0, 0), 
('month', 'May', 0, 0), 
('month', 'Jun', 0, 0), 
('month', 'Jul', 0, 0), 
('month', 'Aug', 0, 0), 
('month', 'Sep', 0, 0), 
('month', 'Oct', 0, 0), 
('month', 'Nov', 0, 0), 
('month', 'Dec', 0, 0), 
('day', '01', 0, 0), 
('day', '02', 0, 0), 
('day', '03', 0, 0), 
('day', '04', 0, 0), 
('day', '05', 0, 0), 
('day', '06', 0, 0), 
('day', '07', 0, 0), 
('day', '08', 0, 0), 
('day', '09', 0, 0), 
('day', '10', 0, 0), 
('day', '11', 0, 0), 
('day', '12', 0, 0), 
('day', '13', 0, 0), 
('day', '14', 0, 0), 
('day', '15', 0, 0), 
('day', '16', 0, 0), 
('day', '17', 0, 0), 
('day', '18', 0, 0), 
('day', '19', 0, 0), 
('day', '20', 0, 0), 
('day', '21', 0, 0), 
('day', '22', 0, 0), 
('day', '23', 0, 0), 
('day', '24', 0, 0), 
('day', '25', 0, 0), 
('day', '26', 0, 0), 
('day', '27', 0, 0), 
('day', '28', 0, 0), 
('day', '29', 0, 0), 
('day', '30', 0, 0), 
('day', '31', 0, 0), 
('dayofweek', 'Sunday', 0, 0), 
('dayofweek', 'Monday', 0, 0), 
('dayofweek', 'Tuesday', 0, 0), 
('dayofweek', 'Wednesday', 0, 0), 
('dayofweek', 'Thursday', 0, 0), 
('dayofweek', 'Friday', 0, 0), 
('dayofweek', 'Saturday', 0, 0), 
('hour', '00', 0, 0), 
('hour', '01', 0, 0), 
('hour', '02', 0, 0), 
('hour', '03', 0, 0), 
('hour', '04', 0, 0), 
('hour', '05', 0, 0), 
('hour', '06', 0, 0), 
('hour', '07', 0, 0), 
('hour', '08', 0, 0), 
('hour', '09', 0, 0), 
('hour', '10', 0, 0), 
('hour', '11', 0, 0), 
('hour', '12', 0, 0), 
('hour', '13', 0, 0), 
('hour', '14', 0, 0), 
('hour', '15', 0, 0), 
('hour', '16', 0, 0), 
('hour', '17', 0, 0), 
('hour', '18', 0, 0), 
('hour', '19', 0, 0), 
('hour', '20', 0, 0), 
('hour', '21', 0, 0), 
('hour', '22', 0, 0), 
('hour', '23', 0, 0), 
('bot', 'Alexa', 0, 0), 
('bot', 'AltaVista Scooter', 0, 0), 
('bot', 'Altavista Mercator', 0, 0), 
('bot', 'Altavista Search', 0, 0), 
('bot', 'Aport.ru Bot', 0, 0), 
('bot', 'Ask Jeeves', 0, 0), 
('bot', 'Baidu', 0, 0), 
('bot', 'Exabot', 0, 0), 
('bot', 'FAST Enterprise', 0, 0), 
('bot', 'FAST WebCrawler', 0, 0), 
('bot', 'Francis', 0, 0), 
('bot', 'Gigablast', 0, 0), 
('bot', 'Google AdsBot', 0, 0), 
('bot', 'Google Adsense', 0, 0), 
('bot', 'Google Bot', 0, 0), 
('bot', 'Google Desktop', 0, 0), 
('bot', 'Google Feedfetcher', 0, 0), 
('bot', 'Heise IT-Markt', 0, 0), 
('bot', 'Heritrix', 0, 0), 
('bot', 'IBM Research', 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0), 
('bot', 'Ichiro', 0, 0), 
('bot', 'InfoSeek Spider', 0, 0), 
('bot', 'Lycos.com Bot', 0, 0), 
('bot', 'MSN Bot', 0, 0), 
('bot', 'MSN Bot Media', 0, 0), 
('bot', 'MSN Bot News', 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0), 
('bot', 'Majestic-12', 0, 0), 
('bot', 'Metager', 0, 0), 
('bot', 'NG-Search', 0, 0), 
('bot', 'Nutch Bot', 0, 0), 
('bot', 'NutchCVS', 0, 0), 
('bot', 'OmniExplorer', 0, 0), 
('bot', 'Online Link Validator', 0, 0), 
('bot', 'Open-source Web Search', 0, 0), 
('bot', 'Psbot', 0, 0), 
('bot', 'Rambler', 0, 0), 
('bot', 'SEO Crawler', 0, 0), 
('bot', 'SEOSearch', 0, 0), 
('bot', 'Seekport', 0, 0), 
('bot', 'Sensis', 0, 0), 
('bot', 'Seoma', 0, 0), 
('bot', 'Snappy', 0, 0), 
('bot', 'Steeler', 0, 0), 
('bot', 'Synoo', 0, 0), 
('bot', 'Telekom', 0, 0), 
('bot', 'TurnitinBot', 0, 0), 
('bot', 'Vietnamese Search', 0, 0), 
('bot', 'Voyager', 0, 0), 
('bot', 'W3 Sitesearch', 0, 0), 
('bot', 'W3C Linkcheck', 0, 0), 
('bot', 'W3C Validator', 0, 0), 
('bot', 'WiseNut', 0, 0), 
('bot', 'YaCy', 0, 0), 
('bot', 'Yahoo Bot', 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0), 
('bot', 'Yahoo Slurp', 0, 0), 
('bot', 'YahooSeeker', 0, 0), 
('bot', 'Yandex', 0, 0), 
('bot', 'Yandex Blog', 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0), 
('bot', 'Yandex Something', 0, 0), 
('browser', 'netcaptor', 0, 0), 
('browser', 'opera', 0, 0), 
('browser', 'aol', 0, 0), 
('browser', 'aol2', 0, 0), 
('browser', 'mosaic', 0, 0), 
('browser', 'k-meleon', 0, 0), 
('browser', 'konqueror', 0, 0), 
('browser', 'avantbrowser', 0, 0), 
('browser', 'avantgo', 0, 0), 
('browser', 'proxomitron', 0, 0), 
('browser', 'chrome', 0, 0), 
('browser', 'safari', 0, 0), 
('browser', 'lynx', 0, 0), 
('browser', 'links', 0, 0), 
('browser', 'galeon', 0, 0), 
('browser', 'abrowse', 0, 0), 
('browser', 'amaya', 0, 0), 
('browser', 'ant', 0, 0), 
('browser', 'aweb', 0, 0), 
('browser', 'beonex', 0, 0), 
('browser', 'blazer', 0, 0), 
('browser', 'camino', 0, 0), 
('browser', 'chimera', 0, 0), 
('browser', 'columbus', 0, 0), 
('browser', 'crazybrowser', 0, 0), 
('browser', 'curl', 0, 0), 
('browser', 'deepnet', 0, 0), 
('browser', 'dillo', 0, 0), 
('browser', 'doris', 0, 0), 
('browser', 'elinks', 0, 0), 
('browser', 'epiphany', 0, 0), 
('browser', 'ibrowse', 0, 0), 
('browser', 'icab', 0, 0), 
('browser', 'ice', 0, 0), 
('browser', 'isilox', 0, 0), 
('browser', 'lotus', 0, 0), 
('browser', 'lunascape', 0, 0), 
('browser', 'maxthon', 0, 0), 
('browser', 'mbrowser', 0, 0), 
('browser', 'multibrowser', 0, 0), 
('browser', 'nautilus', 0, 0), 
('browser', 'netfront', 0, 0), 
('browser', 'netpositive', 0, 0), 
('browser', 'omniweb', 0, 0), 
('browser', 'oregano', 0, 0), 
('browser', 'phaseout', 0, 0), 
('browser', 'plink', 0, 0), 
('browser', 'phoenix', 0, 0), 
('browser', 'shiira', 0, 0), 
('browser', 'sleipnir', 0, 0), 
('browser', 'slimbrowser', 0, 0), 
('browser', 'staroffice', 0, 0), 
('browser', 'sunrise', 0, 0), 
('browser', 'voyager', 0, 0), 
('browser', 'w3m', 0, 0), 
('browser', 'webtv', 0, 0), 
('browser', 'xiino', 0, 0), 
('browser', 'explorer', 0, 0), 
('browser', 'firefox', 0, 0), 
('browser', 'netscape', 0, 0), 
('browser', 'netscape2', 0, 0), 
('browser', 'mozilla', 0, 0), 
('browser', 'mozilla2', 0, 0), 
('browser', 'firebird', 0, 0), 
('browser', 'Mobile', 0, 0), 
('browser', 'Unknown', 0, 0), 
('os', 'windows7', 0, 0), 
('os', 'windowsvista', 0, 0), 
('os', 'windows2003', 0, 0), 
('os', 'windowsxp', 0, 0), 
('os', 'windowsxp2', 0, 0), 
('os', 'windows2k', 0, 0), 
('os', 'windows95', 0, 0), 
('os', 'windowsce', 0, 0), 
('os', 'windowsme', 0, 0), 
('os', 'windowsme2', 0, 0), 
('os', 'windowsnt', 0, 0), 
('os', 'windowsnt2', 0, 0), 
('os', 'windows98', 0, 0), 
('os', 'windows', 0, 0), 
('os', 'linux', 0, 0), 
('os', 'linux2', 0, 0), 
('os', 'linux3', 0, 0), 
('os', 'macosx', 0, 0), 
('os', 'macppc', 0, 0), 
('os', 'mac', 0, 0), 
('os', 'amiga', 0, 0), 
('os', 'beos', 0, 0), 
('os', 'freebsd', 0, 0), 
('os', 'freebsd2', 0, 0), 
('os', 'irix', 0, 0), 
('os', 'netbsd', 0, 0), 
('os', 'netbsd2', 0, 0), 
('os', 'os2', 0, 0), 
('os', 'os22', 0, 0), 
('os', 'openbsd', 0, 0), 
('os', 'openbsd2', 0, 0), 
('os', 'palm', 0, 0), 
('os', 'palm2', 0, 0), 
('os', 'Unspecified', 0, 0), 
('country', 'AD', 0, 0), 
('country', 'AE', 0, 0), 
('country', 'AF', 0, 0), 
('country', 'AG', 0, 0), 
('country', 'AI', 0, 0), 
('country', 'AL', 0, 0), 
('country', 'AM', 0, 0), 
('country', 'AN', 0, 0), 
('country', 'AO', 0, 0), 
('country', 'AQ', 0, 0), 
('country', 'AR', 0, 0), 
('country', 'AS', 0, 0), 
('country', 'AT', 0, 0), 
('country', 'AU', 0, 0), 
('country', 'AW', 0, 0), 
('country', 'AZ', 0, 0), 
('country', 'BA', 0, 0), 
('country', 'BB', 0, 0), 
('country', 'BD', 0, 0), 
('country', 'BE', 0, 0), 
('country', 'BF', 0, 0), 
('country', 'BG', 0, 0), 
('country', 'BH', 0, 0), 
('country', 'BI', 0, 0), 
('country', 'BJ', 0, 0), 
('country', 'BM', 0, 0), 
('country', 'BN', 0, 0), 
('country', 'BO', 0, 0), 
('country', 'BR', 0, 0), 
('country', 'BS', 0, 0), 
('country', 'BT', 0, 0), 
('country', 'BW', 0, 0), 
('country', 'BY', 0, 0), 
('country', 'BZ', 0, 0), 
('country', 'CA', 0, 0), 
('country', 'CD', 0, 0), 
('country', 'CF', 0, 0), 
('country', 'CG', 0, 0), 
('country', 'CH', 0, 0), 
('country', 'CI', 0, 0), 
('country', 'CK', 0, 0), 
('country', 'CL', 0, 0), 
('country', 'CM', 0, 0), 
('country', 'CN', 0, 0), 
('country', 'CO', 0, 0), 
('country', 'CR', 0, 0), 
('country', 'CS', 0, 0), 
('country', 'CU', 0, 0), 
('country', 'CV', 0, 0), 
('country', 'CY', 0, 0), 
('country', 'CZ', 0, 0), 
('country', 'DE', 0, 0), 
('country', 'DJ', 0, 0), 
('country', 'DK', 0, 0), 
('country', 'DM', 0, 0), 
('country', 'DO', 0, 0), 
('country', 'DZ', 0, 0), 
('country', 'EC', 0, 0), 
('country', 'EE', 0, 0), 
('country', 'EG', 0, 0), 
('country', 'ER', 0, 0), 
('country', 'ES', 0, 0), 
('country', 'ET', 0, 0), 
('country', 'EU', 0, 0), 
('country', 'FI', 0, 0), 
('country', 'FJ', 0, 0), 
('country', 'FK', 0, 0), 
('country', 'FM', 0, 0), 
('country', 'FO', 0, 0), 
('country', 'FR', 0, 0), 
('country', 'GA', 0, 0), 
('country', 'GB', 0, 0), 
('country', 'GD', 0, 0), 
('country', 'GE', 0, 0), 
('country', 'GF', 0, 0), 
('country', 'GH', 0, 0), 
('country', 'GI', 0, 0), 
('country', 'GL', 0, 0), 
('country', 'GM', 0, 0), 
('country', 'GN', 0, 0), 
('country', 'GP', 0, 0), 
('country', 'GQ', 0, 0), 
('country', 'GR', 0, 0), 
('country', 'GS', 0, 0), 
('country', 'GT', 0, 0), 
('country', 'GU', 0, 0), 
('country', 'GW', 0, 0), 
('country', 'GY', 0, 0), 
('country', 'HK', 0, 0), 
('country', 'HN', 0, 0), 
('country', 'HR', 0, 0), 
('country', 'HT', 0, 0), 
('country', 'HU', 0, 0), 
('country', 'ID', 0, 0), 
('country', 'IE', 0, 0), 
('country', 'IL', 0, 0), 
('country', 'IN', 0, 0), 
('country', 'IO', 0, 0), 
('country', 'IQ', 0, 0), 
('country', 'IR', 0, 0), 
('country', 'IS', 0, 0), 
('country', 'IT', 0, 0), 
('country', 'JM', 0, 0), 
('country', 'JO', 0, 0), 
('country', 'JP', 0, 0), 
('country', 'KE', 0, 0), 
('country', 'KG', 0, 0), 
('country', 'KH', 0, 0), 
('country', 'KI', 0, 0), 
('country', 'KM', 0, 0), 
('country', 'KN', 0, 0), 
('country', 'KR', 0, 0), 
('country', 'KW', 0, 0), 
('country', 'KY', 0, 0), 
('country', 'KZ', 0, 0), 
('country', 'LA', 0, 0), 
('country', 'LB', 0, 0), 
('country', 'LC', 0, 0), 
('country', 'LI', 0, 0), 
('country', 'LK', 0, 0), 
('country', 'LR', 0, 0), 
('country', 'LS', 0, 0), 
('country', 'LT', 0, 0), 
('country', 'LU', 0, 0), 
('country', 'LV', 0, 0), 
('country', 'LY', 0, 0), 
('country', 'MA', 0, 0), 
('country', 'MC', 0, 0), 
('country', 'MD', 0, 0), 
('country', 'MG', 0, 0), 
('country', 'MH', 0, 0), 
('country', 'MK', 0, 0), 
('country', 'ML', 0, 0), 
('country', 'MM', 0, 0), 
('country', 'MN', 0, 0), 
('country', 'MO', 0, 0), 
('country', 'MP', 0, 0), 
('country', 'MQ', 0, 0), 
('country', 'MR', 0, 0), 
('country', 'MT', 0, 0), 
('country', 'MU', 0, 0), 
('country', 'MV', 0, 0), 
('country', 'MW', 0, 0), 
('country', 'MX', 0, 0), 
('country', 'MY', 0, 0), 
('country', 'MZ', 0, 0), 
('country', 'NA', 0, 0), 
('country', 'NC', 0, 0), 
('country', 'NE', 0, 0), 
('country', 'NF', 0, 0), 
('country', 'NG', 0, 0), 
('country', 'NI', 0, 0), 
('country', 'NL', 0, 0), 
('country', 'NO', 0, 0), 
('country', 'NP', 0, 0), 
('country', 'NR', 0, 0), 
('country', 'NU', 0, 0), 
('country', 'NZ', 0, 0), 
('country', 'OM', 0, 0), 
('country', 'PA', 0, 0), 
('country', 'PE', 0, 0), 
('country', 'PF', 0, 0), 
('country', 'PG', 0, 0), 
('country', 'PH', 0, 0), 
('country', 'PK', 0, 0), 
('country', 'PL', 0, 0), 
('country', 'PR', 0, 0), 
('country', 'PS', 0, 0), 
('country', 'PT', 0, 0), 
('country', 'PW', 0, 0), 
('country', 'PY', 0, 0), 
('country', 'QA', 0, 0), 
('country', 'RE', 0, 0), 
('country', 'RO', 0, 0), 
('country', 'RU', 0, 0), 
('country', 'RW', 0, 0), 
('country', 'SA', 0, 0), 
('country', 'SB', 0, 0), 
('country', 'SC', 0, 0), 
('country', 'SD', 0, 0), 
('country', 'SE', 0, 0), 
('country', 'SG', 0, 0), 
('country', 'SI', 0, 0), 
('country', 'SK', 0, 0), 
('country', 'SL', 0, 0), 
('country', 'SM', 0, 0), 
('country', 'SN', 0, 0), 
('country', 'SO', 0, 0), 
('country', 'SR', 0, 0), 
('country', 'ST', 0, 0), 
('country', 'SV', 0, 0), 
('country', 'SY', 0, 0), 
('country', 'SZ', 0, 0), 
('country', 'TD', 0, 0), 
('country', 'TF', 0, 0), 
('country', 'TG', 0, 0), 
('country', 'TH', 0, 0), 
('country', 'TJ', 0, 0), 
('country', 'TK', 0, 0), 
('country', 'TL', 0, 0), 
('country', 'TM', 0, 0), 
('country', 'TN', 0, 0), 
('country', 'TO', 0, 0), 
('country', 'TR', 0, 0), 
('country', 'TT', 0, 0), 
('country', 'TV', 0, 0), 
('country', 'TW', 0, 0), 
('country', 'TZ', 0, 0), 
('country', 'UA', 0, 0), 
('country', 'UG', 0, 0), 
('country', 'US', 0, 0), 
('country', 'UY', 0, 0), 
('country', 'UZ', 0, 0), 
('country', 'VA', 0, 0), 
('country', 'VC', 0, 0), 
('country', 'VE', 0, 0), 
('country', 'VG', 0, 0), 
('country', 'VI', 0, 0), 
('country', 'VN', 0, 0), 
('country', 'VU', 0, 0), 
('country', 'WS', 0, 0), 
('country', 'YE', 0, 0), 
('country', 'YT', 0, 0), 
('country', 'YU', 0, 0), 
('country', 'ZA', 0, 0), 
('country', 'ZM', 0, 0), 
('country', 'ZW', 0, 0), 
('country', 'ZZ', 0, 0), 
('country', 'unkown', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_menu_menu`
--

DROP TABLE IF EXISTS `nv3_en_menu_menu`;
CREATE TABLE `nv3_en_menu_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `menu_item` mediumtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_menu_rows`
--

DROP TABLE IF EXISTS `nv3_en_menu_rows`;
CREATE TABLE `nv3_en_menu_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` mediumtext NOT NULL,
  `who_view` tinyint(2) NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `op` varchar(255) NOT NULL DEFAULT '',
  `target` tinyint(4) NOT NULL DEFAULT '0',
  `css` varchar(255) NOT NULL DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_modfuncs`
--

DROP TABLE IF EXISTS `nv3_en_modfuncs`;
CREATE TABLE `nv3_en_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=52  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_modfuncs`
--

INSERT INTO `nv3_en_modfuncs` VALUES
(1, 'Sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'Main', 'about', 1, 0, 1, ''), 
(3, 'Sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(4, 'comment', 'Comment', 'news', 0, 0, 0, ''), 
(5, 'content', 'Content', 'news', 1, 0, 1, ''), 
(6, 'detail', 'Detail', 'news', 1, 0, 2, ''), 
(7, 'main', 'Main', 'news', 1, 0, 3, ''), 
(8, 'postcomment', 'Postcomment', 'news', 0, 0, 0, ''), 
(9, 'print', 'Print', 'news', 0, 0, 0, ''), 
(10, 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(11, 'rss', 'Rss', 'news', 0, 0, 0, ''), 
(12, 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(13, 'search', 'Search', 'news', 1, 0, 4, ''), 
(14, 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(15, 'topic', 'Topic', 'news', 1, 0, 5, ''), 
(16, 'viewcat', 'Viewcat', 'news', 1, 0, 6, ''), 
(17, 'active', 'Active', 'users', 1, 0, 8, ''), 
(18, 'changepass', 'Changepass', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'Login', 'users', 1, 1, 2, ''), 
(21, 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'Lostpass', 'users', 1, 1, 5, ''), 
(24, 'main', 'Main', 'users', 1, 1, 1, ''), 
(25, 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'Register', 'users', 1, 1, 4, ''), 
(27, 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'Allbots', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'Allbrowsers', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'Allcountries', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'Allos', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'Allreferers', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'Referer', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'Main', 'voting', 1, 0, 0, ''), 
(36, 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'adv', 'Adv', 'search', 0, 0, 0, ''), 
(46, 'main', 'Main', 'search', 1, 0, 1, ''), 
(47, 'main', 'Main', 'rss', 1, 0, 1, ''), 
(48, 'regroups', 'Regroups', 'users', 1, 0, 1, ''), 
(50, 'memberlist', 'Member List', 'users', 1, 1, 1, ''), 
(51, 'groups', 'Groups', 'news', 1, 0, 7, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_modthemes`
--

DROP TABLE IF EXISTS `nv3_en_modthemes`;
CREATE TABLE `nv3_en_modthemes` (
  `func_id` int(11) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_modthemes`
--

INSERT INTO `nv3_en_modthemes` VALUES
(0, 'body', 'mobile_nukeviet'), 
(0, 'body-right', 'modern'), 
(0, 'left-body-right', 'default'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'left-body-right', 'default'), 
(5, 'body', 'mobile_nukeviet'), 
(5, 'body-right', 'modern'), 
(5, 'left-body-right', 'default'), 
(6, 'body', 'mobile_nukeviet'), 
(6, 'body-right', 'modern'), 
(6, 'left-body-right', 'default'), 
(7, 'body', 'mobile_nukeviet'), 
(7, 'body-right', 'modern'), 
(7, 'left-body-right', 'default'), 
(13, 'body', 'mobile_nukeviet'), 
(13, 'body-right', 'modern'), 
(13, 'left-body-right', 'default'), 
(15, 'body', 'mobile_nukeviet'), 
(15, 'body-right', 'modern'), 
(15, 'left-body-right', 'default'), 
(16, 'body', 'mobile_nukeviet'), 
(16, 'body-right', 'modern'), 
(16, 'left-body-right', 'default'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body-right', 'modern'), 
(17, 'left-body-right', 'default'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body-right', 'modern'), 
(18, 'left-body-right', 'default'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body-right', 'modern'), 
(19, 'left-body-right', 'default'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body-right', 'modern'), 
(20, 'left-body-right', 'default'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body-right', 'modern'), 
(21, 'left-body-right', 'default'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body-right', 'modern'), 
(22, 'left-body-right', 'default'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body-right', 'modern'), 
(23, 'left-body-right', 'default'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body-right', 'modern'), 
(24, 'left-body-right', 'default'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body-right', 'modern'), 
(25, 'left-body-right', 'default'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body-right', 'modern'), 
(26, 'left-body-right', 'default'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body-right', 'modern'), 
(27, 'left-body-right', 'default'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'left-body', 'default'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'left-body', 'default'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'left-body', 'default'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'left-body', 'default'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'left-body', 'default'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'left-body', 'default'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'left-body', 'default'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body-right', 'modern'), 
(35, 'left-body-right', 'default'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body-right', 'modern'), 
(36, 'left-body-right', 'default'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body-right', 'modern'), 
(39, 'left-body-right', 'default'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body-right', 'modern'), 
(42, 'left-body-right', 'default'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body-right', 'modern'), 
(43, 'left-body-right', 'default'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body-right', 'modern'), 
(46, 'left-body-right', 'default'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'left-body-right', 'default'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body-right', 'modern'), 
(48, 'left-body-right', 'default'), 
(50, 'body', 'mobile_nukeviet'), 
(50, 'body-right', 'modern'), 
(50, 'left-body-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_modules`
--

DROP TABLE IF EXISTS `nv3_en_modules`;
CREATE TABLE `nv3_en_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_modules`
--

INSERT INTO `nv3_en_modules` VALUES
('about', 'about', 'about', 'About', '', 1276333182, 1, 1, '', 'mobile_nukeviet', '', '', '0', 1, 1, 1, 1, '', 0), 
('news', 'news', 'news', 'News', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '', '0', 1, 2, 1, 1, '', 1), 
('users', 'users', 'users', 'Users', '', 1274080277, 1, 1, '', 'mobile_nukeviet', '', '', '0', 1, 3, 1, 1, '', 0), 
('contact', 'contact', 'contact', 'Contact', '', 1275351337, 1, 1, '', 'mobile_nukeviet', '', '', '0', 1, 4, 1, 1, '', 0), 
('statistics', 'statistics', 'statistics', 'Statistics', '', 1276520928, 1, 0, '', 'mobile_nukeviet', '', 'online, statistics', '0', 1, 5, 1, 1, '', 0), 
('voting', 'voting', 'voting', 'Voting', '', 1275315261, 1, 1, '', 'mobile_nukeviet', '', '', '0', 0, 6, 1, 1, '', 1), 
('banners', 'banners', 'banners', 'Banners', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '', '0', 0, 7, 1, 1, '', 0), 
('search', 'search', 'search', 'Search', '', 1273474173, 1, 0, '', 'mobile_nukeviet', '', '', '0', 0, 8, 1, 1, '', 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', 'mobile_nukeviet', '', '', '0', 0, 9, 1, 1, '', 0), 
('rss', 'rss', 'rss', 'Rss', '', 1279366705, 1, 1, '', 'mobile_nukeviet', '', '', '0', 0, 10, 1, 1, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_1`
--

DROP TABLE IF EXISTS `nv3_en_news_1`;
CREATE TABLE `nv3_en_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_1`
--

INSERT INTO `nv3_en_news_1` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 2, 0, 0, 0, 'VINADES');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_10`
--

DROP TABLE IF EXISTS `nv3_en_news_10`;
CREATE TABLE `nv3_en_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_11`
--

DROP TABLE IF EXISTS `nv3_en_news_11`;
CREATE TABLE `nv3_en_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_12`
--

DROP TABLE IF EXISTS `nv3_en_news_12`;
CREATE TABLE `nv3_en_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_12`
--

INSERT INTO `nv3_en_news_12` VALUES
(3, 12, '12,7', 0, 8, '', 2, 1277691851, 1287160943, 1, 1277691840, 0, 2, 'HTML 5 review', 'HTML-5-review', 'I have to say that my money used to be on XHTML 2.0 eventually winning the battle for the next great web standard. Either that, or the two titans would continue to battle it out for the forseable future, leading to an increasingly fragmented web.', 'screenshot.jpg', '', 'thumb/screenshot.jpg|block/screenshot.jpg', 1, 2, 1, 2, 0, 0, 0, 'HTML5');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_13`
--

DROP TABLE IF EXISTS `nv3_en_news_13`;
CREATE TABLE `nv3_en_news_13` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_14`
--

DROP TABLE IF EXISTS `nv3_en_news_14`;
CREATE TABLE `nv3_en_news_14` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_14`
--

INSERT INTO `nv3_en_news_14` VALUES
(2, 14, '14,8', 0, 8, '', 1, 1277691366, 1277691470, 1, 1277691360, 0, 2, 'What does WWW mean?', 'What-does-WWW-mean', 'The World Wide Web, abbreviated as WWW and commonly known as the Web, is a system of interlinked hypertext&nbsp; documents accessed via the Internet.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 0, 0, 0, 0, 'Web');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_2`
--

DROP TABLE IF EXISTS `nv3_en_news_2`;
CREATE TABLE `nv3_en_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_3`
--

DROP TABLE IF EXISTS `nv3_en_news_3`;
CREATE TABLE `nv3_en_news_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_4`
--

DROP TABLE IF EXISTS `nv3_en_news_4`;
CREATE TABLE `nv3_en_news_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_4`
--

INSERT INTO `nv3_en_news_4` VALUES
(4, 4, '4', 0, 1, 'VOVNews&#x002F;VNA', 0, 1292959020, 1292959513, 1, 1292959020, 0, 2, 'First open-source company starts operation', 'First-open-source-company-starts-operation', 'The Vietnam Open Source Development Joint Stock Company (VINADES.,JSC), the first firm operating in the field of open source in the country, made its debut on February 25.', 'nangly.jpg', '', 'thumb/nangly.jpg|thumb/nangly.jpg', 1, 2, 1, 1, 0, 0, 0, 'VINADES, Nguyen Anh Tu'), 
(5, 4, '4', 0, 1, '', 0, 1292959490, 1292959664, 1, 1292959440, 0, 2, 'NukeViet 3.0 - New CMS for News site', 'NukeViet-30-New-CMS-for-News-site', 'NukeViet 3.0 is a professional system: VINADES.,JSC founded to maintain and improve NukeViet 3.0 features. VINADES.,JSC co-operated with many professional hosting providers to test compatibility issues.', 'nukeviet3.jpg', '', 'thumb/nukeviet3.jpg|thumb/nukeviet3.jpg', 1, 2, 1, 1, 0, 0, 0, 'NukeViet, VINADES');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_5`
--

DROP TABLE IF EXISTS `nv3_en_news_5`;
CREATE TABLE `nv3_en_news_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_6`
--

DROP TABLE IF EXISTS `nv3_en_news_6`;
CREATE TABLE `nv3_en_news_6` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_7`
--

DROP TABLE IF EXISTS `nv3_en_news_7`;
CREATE TABLE `nv3_en_news_7` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_7`
--

INSERT INTO `nv3_en_news_7` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 2, 0, 0, 0, 'VINADES'), 
(3, 12, '12,7', 0, 8, '', 2, 1277691851, 1287160943, 1, 1277691840, 0, 2, 'HTML 5 review', 'HTML-5-review', 'I have to say that my money used to be on XHTML 2.0 eventually winning the battle for the next great web standard. Either that, or the two titans would continue to battle it out for the forseable future, leading to an increasingly fragmented web.', 'screenshot.jpg', '', 'thumb/screenshot.jpg|block/screenshot.jpg', 1, 2, 1, 2, 0, 0, 0, 'HTML5');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_8`
--

DROP TABLE IF EXISTS `nv3_en_news_8`;
CREATE TABLE `nv3_en_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_8`
--

INSERT INTO `nv3_en_news_8` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 2, 0, 0, 0, 'VINADES'), 
(2, 14, '14,8', 0, 8, '', 1, 1277691366, 1277691470, 1, 1277691360, 0, 2, 'What does WWW mean?', 'What-does-WWW-mean', 'The World Wide Web, abbreviated as WWW and commonly known as the Web, is a system of interlinked hypertext&nbsp; documents accessed via the Internet.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 0, 0, 0, 0, 'Web');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_9`
--

DROP TABLE IF EXISTS `nv3_en_news_9`;
CREATE TABLE `nv3_en_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_admins`
--

DROP TABLE IF EXISTS `nv3_en_news_admins`;
CREATE TABLE `nv3_en_news_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_block`
--

DROP TABLE IF EXISTS `nv3_en_news_block`;
CREATE TABLE `nv3_en_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_block_cat`
--

DROP TABLE IF EXISTS `nv3_en_news_block_cat`;
CREATE TABLE `nv3_en_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_block_cat`
--

INSERT INTO `nv3_en_news_block_cat` VALUES
(1, 0, 4, 'Hot News', 'Hot-News', '', '', '', 1, '', 1279963759, 1279963759), 
(2, 1, 4, 'Top News', 'Top-News', '', '', '', 2, '', 1279963766, 1279963766);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv3_en_news_bodyhtml_1`;
CREATE TABLE `nv3_en_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_bodyhtml_1`
--

INSERT INTO `nv3_en_news_bodyhtml_1` VALUES
(1, '<p> <span style=\"color: black;\"><span style=\"color: black;\"><font size=\"2\"><span style=\"font-family: verdana,sans-serif;\">VIETNAM OPEN SOURCE DEVELOPMENT COMPANY (VINADES.,JSC)<br  /> Head office: Room 1805 – CT2 Nang Huong building, 583 Nguyen Trai street, Hanoi, Vietnam.<br  /> Mobile: (+84)4 8587 2007<br  /> Fax: (+84) 4 3550 0914<br  /> Website: <a f8f55ee40942436149=\"true\" href=\"http://www.vinades.vn/\" target=\"_blank\">www.vinades.vn</a> - <a f8f55ee40942436149=\"true\" href=\"http://www.nukeviet.vn/\" target=\"_blank\">www.nukeviet.vn</a></span></font></span></span></p><div h4f82558737983=\"nukeviet.vn\" style=\"display: inline; cursor: pointer; padding-right: 16px; width: 16px; height: 16px;\"> <span style=\"color: black;\"><span style=\"color: black;\"><font size=\"2\"><span style=\"font-family: verdana,sans-serif;\">&nbsp;</span></font></span></span></div><br  /><p> <span style=\"color: black;\"><span style=\"color: black;\"><font size=\"2\"><span style=\"font-family: verdana,sans-serif;\">Email: <a href=\"mailto:contact@vinades.vn\" target=\"_blank\">contact@vinades.vn</a><br  /> <br  /> <br  /> Dear valued customers and partners,<br  /> <br  /> VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing.<br  /> <br  /> NukeViet is a Content Management System (CMS). 1st general purpose CMS developed by Vietnamese community. It have so many pros. Ex: Biggest community in VietNam, pure Vietnamese, easy to use, easy to develop...<br  /> <br  /> NukeViet 3 is lastest version of NukeViet and it still developing but almost complete with many advantage features.<br  /> <br  /> With respects to invite hosting - domain providers, and all company that pay attension to NukeViet in bussiness co-operate.<br  /> <br  /> Co-operate types:<br  /> <br  /> 1. Website advertisement, banners exchange, links:<br  /> a. Description:<br  /> Website advertising &amp; communication channels.<br  /> On each release version of NukeViet.<br  /> b. Benefits:<br  /> Broadcast to all end users on both side.<br  /> Reduce advertisement cost.<br  /> c. Warranties:<br  /> Place advertisement banner of partners on both side.<br  /> Open sub-forum at NukeViet.VN to support end users who using hosting services providing by partners.<br  /> <br  /> 2. Provide host packet for NukeViet development testing purpose:<br  /> <br  /> a. Description:<br  /> Sign the contract and agreements.<br  /> Partners provide all types of hosting packet for VINADES.,JSC. Each type at least 1 re-sale packet.<br  /> VINADES.,JSC provide an certificate verify host providing by partner compartable with NukeViet.<br  /> b. Benefits:<br  /> Expand market.<br  /> Reduce cost, improve bussiness value.<br  /> c. Warranties:<br  /> Partner provide free hosting packet for VINADES.,JSC to test NukeViet compatibility.<br  /> VINADES.JSC annoucement tested result to community.<br  /> <br  /> 3. Support end users:<br  /> a. Description:<br  /> Co-operate to solve problem of end user.<br  /> Partners send end user requires about NukeViet CMS to VINADES.,JSC. VINADES also send user requires about hosting services to partners.<br  /> b. Benefits:<br  /> Reduce cost, human resources to support end users.<br  /> Support end user more effective.<br  /> c. Warranties:<br  /> Solve end user requires as soon as possible.<br  /> <br  /> 4. Other types:<br  /> Besides, as a publisher of NukeViet CMS, we also place advertisements on software user interface, sample articles in each release version. With thousands of downloaded hits each release version, we believe that it is the most effective advertisement type to webmasters.<br  /> If partners have any ideas about new co-operate types. You are welcome and feel free to send specifics to us. Our slogan is &quot;Co-operate for development&quot;.<br  /> <br  /> We look forward to co-operating with you.<br  /> <br  /> Sincerely,<br  /> <br  /> VINADES.,JSC</span></font></span></span></p>', '', 2, 0, 1, 1, 1), 
(2, '<p> With a web browser, one can view web pages&nbsp; that may contain text, images, videos, and other multimedia&nbsp; and navigate between them by using hyperlinks. Using concepts from earlier hypertext systems, British engineer and computer scientist Sir Tim Berners-Lee, now the Director of the World Wide Web Consortium, wrote a proposal in March 1989 for what would eventually become the World Wide Web. He was later joined by Belgian computer scientist Robert Cailliau while both were working at CERN in Geneva, Switzerland. In 1990, they proposed using &quot;HyperText to link and access information of various kinds as a web of nodes in which the user can browse at will&quot;, and released that web in December.<br  /> <br  /> &quot;The World-Wide Web (W3) was developed to be a pool of human knowledge, which would allow collaborators in remote sites to share their ideas and all aspects of a common project.&quot;. If two projects are independently crea-ted, rather than have a central figure make the changes, the two bodies of information could form into one cohesive piece of work.</p><p> For more detail. See <a href=\"http://en.wikipedia.org/wiki/World_Wide_Web\" target=\"_blank\">Wikipedia</a></p>', '', 1, 0, 1, 1, 1), 
(3, '<p> But now that the W3C has admitted defeat, and abandoned <span class=\"caps\">XHTML</span> 2.0, there’s now no getting away f-rom the fact that <span class=\"caps\">HTML</span> 5 is the future. As such, I’ve now spent some time taking a look at this emerging standard, and hope you’ll endulge my ego by taking a glance over my thoughts on the matter.</p><p> Before I get started though, I have to say that I’m very impressed by what I’ve seen. It’s a good set of standards that are being cre-ated, and I hope that they will gradually be adopted over the next few years.</p><h2> New markup</h2><p> <span class=\"caps\">HTML</span> 5 introduces some new markup elements to encourage better structure within documents. The most important of these is &lt;section&gt;, which is used to define a hierarchy within a document. Sections can be nested to define subsections, and each section can be broken up into &lt;header&gt; and &lt;footer&gt; areas.</p><p> The important thing about this addition is that it removes the previous dependancy on &lt;h1&gt;, &lt;h2&gt; and related tags to define structure. Within each &lt;section&gt;, the top level heading is always &lt;h1&gt;. You can use as many &lt;h1&gt; tags as you like within your content, so long as they are correctly nested within &lt;section&gt; tags.</p><p> There’s a plethora of other new tags, all of which seem pretty useful. The best thing about all of this, however, is that there’s no reason not to start using them right away. There’s a small piece of JavaScript that’s needed to make Internet Explorer behave, but aside f-rom that it’s all good. More details about this hack are available at <a href=\"http://www.diveintohtml5.org/\">http://www.diveintohtml5.org</a></p><h2> Easier media embedding</h2><p> <span class=\"caps\">HTML</span> 5 defines some new tags that will make it a lot easier to embed video and audio into pages. In the same way that images are embedded using &lt;img&gt; tags, so now can video and audio files be embedded using &lt;video&gt; and &lt;audio&gt;.</p><p> I don’t think than anyone is going to complain about these new features. They free us f-rom relying on third-party plugins, such as Adobe Flash, for such simple activities such as playing video.</p><p> Unfortunately, due to some annoying licensing conditions and a lack of support for the open-source Theora codec, actually using these tags at the moment requires that videos are encoded in two different formats. Even then, you’ll still need to still provide an Adobe Flash fallback for Internet Explorer.</p><p> You’ll need to be pretty devoted to <span class=\"caps\">HTML</span> 5 to use these tags yet…</p><h2> Relaxed markup rules</h2><p> This is one thorny subject. You know how we’ve all been so good recently with our well-formed <span class=\"caps\">XHTML</span>, quoting those attributes and closing those tags? Now there’s no need to, apparently…</p><p> On the surface, this seems like a big step backwards into the bad days of tag soup. However, if you dig deeper, the reasoning behind this decision goes something like this:</p><ol> <li> It’s unnacceptable to crash out an entire <span class=\"caps\">HTML</span> page just because of a simple <span class=\"caps\">XML</span> syntax error.</li> <li> This means that browsers cannot use an <span class=\"caps\">XML</span> parser, and must instead use a HTML-aware fault-tolerant parser.</li> <li> For consistency, all browsers should handle any such “syntax errors” (such as unquoted attributes and unclosed tags), in the same way.</li> <li> If all browsers are behaving in the same way, then unquoted attributes and unclosed tags are not really syntax errors any more. In fact, by leaving them out of our pages, we can save a few bytes!</li></ol><p> This isn’t to say that you have to throw away those <span class=\"caps\">XHTML</span> coding habits. It’s still all valid <span class=\"caps\">HTML</span> 5. In fact, if you really want to be strict, you can set a different content-type header to enforce well-formed <span class=\"caps\">XHTML</span>. But for most people, we’ll just carry on coding well-formed <span class=\"caps\">HTML</span> with the odd typo, but no longer have to worry about clients screaming at us when the perfectly-rendered page doesn’t validate.</p><h2> So what now?</h2><p> The <span class=\"caps\">HTML</span> 5 specification is getting pretty close to stable, so it’s now safe to use bits of this new standard in your code. How much you use is entirely a personal choice. However, we should all get used to the new markup over the next few years, because <span class=\"caps\">HTML</span> 5 is assuredly here to stay.</p><p> Myself, I’ll be switching to the new doctype and using the new markup for document sections in my code. This step involves very little effort and does a good job of showing support for the new specification.</p><p> The new media tags are another matter. Until all platforms support a single video format, it’s simply not sustainable to be transcoding all videos into two filetypes. When this is coupled with having to provide a Flash fallback, it all seems like a pretty poor return on investment.</p><p> These features will no doubt become more useable over the next few years, as newer browser take the place of old. One day, hopefully, we’ll be able write clean, semantic pages without having to worry about backwards-compatibility.</p><p> Part of this progress relies on web developers using these new standards in our pages. By adopting new technology, we show our support for the standards it represents and place pressure on browser vendors to adhere to those standards. It’s a bit of effort in the short term, but in the long term it will pay dividends.</p>', 'http://www.etianen.com/blog/developers/2010/2/html-5-review/', 2, 0, 1, 1, 1), 
(4, '<p> <span>The Hanoi-based company will further develop and popularise an open source content management system best known as NukeViet in the country. </span></p><p> <span>VINADES Chairman Nguyen Anh Tu said NukeViet is totally free and users can download the product at www.nukeviet.vn. </span></p><p> <span>NukeViet has been widely used across the country over the past five years. The system, built on PHP-Nuke and MySQL database, enables users to easily post and manage files on the Internet or Intranet.</span></p>', '', 0, 0, 1, 1, 1), 
(5, '<p style=\"text-align: justify;\"> NukeViet also testing by many experienced webmasters to optimize system features. NukeViet&#039;s core team are programming enthusiasts. All of them want to make NukeViet become the best and most popular open source CMS.</p><p style=\"text-align: justify;\"> <b>NukeViet 3.0 is a powerful system:</b><br  /> Learn by experiences f-rom NukeViet 2.0, NukeViet 3.0 build ground up on latest web technologies, allow you easily cre-ate portal, online news express, social network, e commerce system.<br  /> NukeViet 3.0 can process huge amount of data. It was used by many companies, corporation&#039;s website with millions of news entries with high traffic.<br  /> <br  /> <b>NukeViet 3.0 is easy to use system:</b><br  /> NukeViet allow you easily to customize and instantly use without any line of code. As developers, NukeViet help you build your own modules rapidly.</p><h2 style=\"text-align: justify;\"> NukeViet 3.0 features:</h2><p style=\"text-align: justify;\"> <b>Technology bases:</b><br  /> NukeViet 3.0 using PHP 5 and MySQL 5 as main programming languages. XTemplate and jQuery for use Ajax f-rom system core.<br  /> NukeViet 3.0 is fully validated with xHTML 1.0, CSS 2.1 and compatible with all major browsers.<br  /> NukeViet 3.0 layout website using grid CSS framework like BluePrintCSS for design templates rapidly.<br  /> <br  /> NukeViet 3.0 has it own core libraries and it is platform independent. You can build your own modules with basic knowledge of PHP and MySQL.<br  /> <br  /> <b>Module structure:</b><br  /> NukeViet 3.0 re-construct module structure. All module files packed into a particular folder. It&#039;s also define module block and module theme for layout modules in many ways.<br  /> <br  /> NukeViet 3.0 support modules can be multiply. We called it abstract modules. It help users automatic cre-ate many modules without any line of code f-rom any exists module which support cre-ate abstract modules.<br  /> <br  /> NukeViet 3.0 support automatic setup modules, blocks, themes f-rom Admin Control Panel. It&#039;s also allow you to share your modules by packed it into packets. NukeViet allow grant, deny access or even re-install, de-lete module.<br  /> <br  /> <b>Multi language:</b><br  /> NukeViet 3 support multi languages in 2 types. Multi interface languages and multi database languages. It had features support administrators to build new languages. In NukeViet 3, admin language, user language, interface language, database language are separate for easily build multi languages systems.<br  /> <br  /> <b>Right:</b><br  /> All manage features only access in admin area. NukeViet 3.0 allow grant access by module and language. It also allow cre-ate user groups and grant access modules by group.<br  /> <br  /> <b>Themes:</b><br  /> NukeViet 3.0 support automatic install and uninstall themes. You can easily customize themes in module and module&#039;s functions. NukeViet store HTML, CSS code separately f-rom PHP code to help designers rapidly layout website.<br  /> <br  /> <b>Customize website using blocks</b><br  /> A block can be a widget, advertisement pictures or any defined data. You can place block in many positions visually by drag and d-rop or argument it in Admin Control Panel.<br  /> <br  /> <b>Securities:</b><br  /> NukeViet using security filters to filter data upload.<br  /> Logging and control access f-rom many search engine as Google, Yahoo or any search engine.<br  /> Anti spam using Captcha, anti flood data...<br  /> NukeViet 3.0 has logging systems to log and track information about client to prevent attack.<br  /> NukeViet 3.0 support automatic up-date to fix security issues or upgrade your website to latest version of NukeViet.<br  /> <br  /> <b>Database:</b><br  /> You can backup database and download backup files to restore database to any point you restored your database.<br  /> <br  /> <b>Control errors report</b><br  /> You can configure to display each type of error only one time. System then sent log files about this error to administrator via email.<br  /> <br  /> <b>SEO:</b><br  /> Support SEO link<br  /> Manage and customize website title<br  /> Manage meta tag<br  /> <br  /> Support keywords for cre-ate statistic via search engine<br  /> <br  /> <b>Prepared for integrate with third party application</b><br  /> NukeViet 3.0 has it own user database and many built-in methods to connect with many forum application. PHPBB or VBB can integrate and use with NukeViet 3.0 by single click.<br  /> <br  /> <b>Distributed login</b><br  /> NukeViet support login by OpenID. Users can login to your website by accounts f-rom popular and well-known provider, such as Google, Yahoo or other OpenID providers. It help your website more accessible and reduce user&#039;s time to filling out registration forms.<br  /> <br  /> Download NukeViet 3.0: <a href=\"http://code.google.com/p/nuke-viet/downloads/list\">http://code.google.com/p/nuke-viet/downloads/list</a><br  /> Website: <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a></p>', '', 2, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_bodytext`
--

DROP TABLE IF EXISTS `nv3_en_news_bodytext`;
CREATE TABLE `nv3_en_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_bodytext`
--

INSERT INTO `nv3_en_news_bodytext` VALUES
(1, ' VIETNAM OPEN SOURCE DEVELOPMENT COMPANY (VINADES.,JSC) Head office: Room 1805 – CT2 Nang Huong building, 583 Nguyen Trai street, Hanoi, Vietnam. Mobile: (+84)4 8587 2007 Fax: (+84) 4 3550 0914 Website: http://www.vinades.vn/ www.vinades.vn - http://www.nukeviet.vn/ www.nukeviet.vn Email: mailto:contact@vinades.vn contact@vinades.vn Dear valued customers and partners, VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. NukeViet is a Content Management System (CMS). 1st general purpose CMS developed by Vietnamese community. It have so many pros. Ex: Biggest community in VietNam, pure Vietnamese, easy to use, easy to develop... NukeViet 3 is lastest version of NukeViet and it still developing but almost complete with many advantage features. With respects to invite hosting - domain providers, and all company that pay attension to NukeViet in bussiness co-operate. Co-operate types: 1. Website advertisement, banners exchange, links: a. Description: Website advertising & communication channels. On each release version of NukeViet. b. Benefits: Broadcast to all end users on both side. Reduce advertisement cost. c. Warranties: Place advertisement banner of partners on both side. Open sub-forum at NukeViet.VN to support end users who using hosting services providing by partners. 2. Provide host packet for NukeViet development testing purpose: a. Description: Sign the contract and agreements. Partners provide all types of hosting packet for VINADES.,JSC. Each type at least 1 re-sale packet. VINADES.,JSC provide an certificate verify host providing by partner compartable with NukeViet. b. Benefits: Expand market. Reduce cost, improve bussiness value. c. Warranties: Partner provide free hosting packet for VINADES.,JSC to test NukeViet compatibility. VINADES.JSC annoucement tested result to community. 3. Support end users: a. Description: Co-operate to solve problem of end user. Partners send end user requires about NukeViet CMS to VINADES.,JSC. VINADES also send user requires about hosting services to partners. b. Benefits: Reduce cost, human resources to support end users. Support end user more effective. c. Warranties: Solve end user requires as soon as possible. 4. Other types: Besides, as a publisher of NukeViet CMS, we also place advertisements on software user interface, sample articles in each release version. With thousands of downloaded hits each release version, we believe that it is the most effective advertisement type to webmasters. If partners have any ideas about new co-operate types. You are welcome and feel free to send specifics to us. Our slogan is \"Co-operate for development\". We look forward to co-operating with you. Sincerely, VINADES.,JSC'), 
(2, ' With a web browser, one can view web pages that may contain text, images, videos, and other multimedia and navigate between them by using hyperlinks. Using concepts f-rom earlier hypertext systems, British engineer and computer scientist Sir Tim Berners-Lee, now the Director of the World Wide Web Consortium, wrote a proposal in March 1989 for what would eventually become the World Wide Web. He was later joined by Belgian computer scientist Robert Cailliau while both were working at CERN in Geneva, Switzerland. In 1990, they proposed using \"HyperText to link and access information of various kinds as a web of nodes in which the user can browse at will\", and released that web in December. \"The World-Wide Web (W3) was developed to be a pool of human knowledge, which would allow collaborators in remote sites to share their ideas and all aspects of a common project.\". If two projects are independently crea-ted, rather than have a central figure make the changes, the two bodies of information could form into one cohesive piece of work. For more detail. See http://en.wikipedia.org/wiki/World_Wide_Web Wikipedia'), 
(3, ' But now that the W3C has admitted defeat, and abandoned XHTML 2.0, there’s now no getting away f-rom the fact that HTML 5 is the future. As such, I’ve now spent some time taking a look at this emerging standard, and hope you’ll endulge my ego by taking a glance over my thoughts on the matter. Before I get started though, I have to say that I’m very impressed by what I’ve seen. It’s a good set of standards that are being cre-ated, and I hope that they will gradually be adopted over the next few years. New markup HTML 5 introduces some new markup elements to encourage better structure within documents. The most important of these is <section>, which is used to define a hierarchy within a document. Sections can be nested to define subsections, and each section can be broken up into <header> and <footer> areas. The important thing about this addition is that it removes the previous dependancy on <h1>, <h2> and related tags to define structure. Within each <section>, the top level heading is always <h1>. You can use as many <h1> tags as you like within your content, so long as they are correctly nested within <section> tags. There’s a plethora of other new tags, all of which seem pretty useful. The best thing about all of this, however, is that there’s no reason not to start using them right away. There’s a small piece of JavaScript that’s needed to make Internet Explorer behave, but aside f-rom that it’s all good. More details about this hack are available at http://www.diveintohtml5.org/ http://www.diveintohtml5.org Easier media embedding HTML 5 defines some new tags that will make it a lot easier to embed video and audio into pages. In the same way that images are embedded using <img> tags, so now can video and audio files be embedded using <video> and <audio>. I don’t think than anyone is going to complain about these new features. They free us f-rom relying on third-party plugins, such as Adobe Flash, for such simple activities such as playing video. Unfortunately, due to some annoying licensing conditions and a lack of support for the open-source Theora codec, actually using these tags at the moment requires that videos are encoded in two different formats. Even then, you’ll still need to still provide an Adobe Flash fallback for Internet Explorer. You’ll need to be pretty devoted to HTML 5 to use these tags yet… Relaxed markup rules This is one thorny subject. You know how we’ve all been so good recently with our well-formed XHTML, quoting those attributes and closing those tags? Now there’s no need to, apparently… On the surface, this seems like a big step backwards into the bad days of tag soup. However, if you dig deeper, the reasoning behind this decision goes something like this: It’s unnacceptable to crash out an entire HTML page just because of a simple XML syntax error. This means that browsers cannot use an XML parser, and must instead use a HTML-aware fault-tolerant parser. For consistency, all browsers should handle any such “syntax errors” (such as unquoted attributes and unclosed tags), in the same way. If all browsers are behaving in the same way, then unquoted attributes and unclosed tags are not really syntax errors any more. In fact, by leaving them out of our pages, we can save a few bytes! This isn’t to say that you have to throw away those XHTML coding habits. It’s still all valid HTML 5. In fact, if you really want to be strict, you can set a different content-type header to enforce well-formed XHTML. But for most people, we’ll just carry on coding well-formed HTML with the odd typo, but no longer have to worry about clients screaming at us when the perfectly-rendered page doesn’t validate. So what now? The HTML 5 specification is getting pretty close to stable, so it’s now safe to use bits of this new standard in your code. How much you use is entirely a personal choice. However, we should all get used to the new markup over the next few years, because HTML 5 is assuredly here to stay. Myself, I’ll be switching to the new doctype and using the new markup for document sections in my code. This step involves very little effort and does a good job of showing support for the new specification. The new media tags are another matter. Until all platforms support a single video format, it’s simply not sustainable to be transcoding all videos into two filetypes. When this is coupled with having to provide a Flash fallback, it all seems like a pretty poor return on investment. These features will no doubt become more useable over the next few years, as newer browser take the place of old. One day, hopefully, we’ll be able write clean, semantic pages without having to worry about backwards-compatibility. Part of this progress relies on web developers using these new standards in our pages. By adopting new technology, we show our support for the standards it represents and place pressure on browser vendors to adhere to those standards. It’s a bit of effort in the short term, but in the long term it will pay dividends.'), 
(4, ' The Hanoi-based company will further develop and popularise an open source content management system best known as NukeViet in the country. VINADES Chairman Nguyen Anh Tu said NukeViet is totally free and users can download the product at www.nukeviet.vn. NukeViet has been widely used across the country over the past five years. The system, built on PHP-Nuke and MySQL database, enables users to easily post and manage files on the Internet or Intranet.'), 
(5, ' NukeViet also testing by many experienced webmasters to optimize system features. NukeViet&#039;s core team are programming enthusiasts. All of them want to make NukeViet become the best and most popular open source CMS. NukeViet 3.0 is a powerful system: Learn by experiences f-rom NukeViet 2.0, NukeViet 3.0 build ground up on latest web technologies, allow you easily cre-ate portal, online news express, social network, e commerce system. NukeViet 3.0 can process huge amount of data. It was used by many companies, corporation&#039;s website with millions of news entries with high traffic. NukeViet 3.0 is easy to use system: NukeViet allow you easily to customize and instantly use without any line of code. As developers, NukeViet help you build your own modules rapidly. NukeViet 3.0 features: Technology bases: NukeViet 3.0 using PHP 5 and MySQL 5 as main programming languages. XTemplate and jQuery for use Ajax f-rom system core. NukeViet 3.0 is fully validated with xHTML 1.0, CSS 2.1 and compatible with all major browsers. NukeViet 3.0 layout website using grid CSS framework like BluePrintCSS for design templates rapidly. NukeViet 3.0 has it own core libraries and it is platform independent. You can build your own modules with basic knowledge of PHP and MySQL. Module structure: NukeViet 3.0 re-construct module structure. All module files packed into a particular folder. It&#039;s also define module block and module theme for layout modules in many ways. NukeViet 3.0 support modules can be multiply. We called it abstract modules. It help users automatic cre-ate many modules without any line of code f-rom any exists module which support cre-ate abstract modules. NukeViet 3.0 support automatic setup modules, blocks, themes f-rom Admin Control Panel. It&#039;s also allow you to share your modules by packed it into packets. NukeViet allow grant, deny access or even re-install, de-lete module. Multi language: NukeViet 3 support multi languages in 2 types. Multi interface languages and multi database languages. It had features support administrators to build new languages. In NukeViet 3, admin language, user language, interface language, database language are separate for easily build multi languages systems. Right: All manage features only access in admin area. NukeViet 3.0 allow grant access by module and language. It also allow cre-ate user groups and grant access modules by group. Themes: NukeViet 3.0 support automatic install and uninstall themes. You can easily customize themes in module and module&#039;s functions. NukeViet store HTML, CSS code separately f-rom PHP code to help designers rapidly layout website. Customize website using blocks A block can be a widget, advertisement pictures or any defined data. You can place block in many positions visually by drag and d-rop or argument it in Admin Control Panel. Securities: NukeViet using security filters to filter data upload. Logging and control access f-rom many search engine as Google, Yahoo or any search engine. Anti spam using Captcha, anti flood data... NukeViet 3.0 has logging systems to log and track information about client to prevent attack. NukeViet 3.0 support automatic up-date to fix security issues or upgrade your website to latest version of NukeViet. Database: You can backup database and download backup files to restore database to any point you restored your database. Control errors report You can configure to display each type of error only one time. System then sent log files about this error to administrator via email. SEO: Support SEO link Manage and customize website title Manage meta tag Support keywords for cre-ate statistic via search engine Prepared for integrate with third party application NukeViet 3.0 has it own user database and many built-in methods to connect with many forum application. PHPBB or VBB can integrate and use with NukeViet 3.0 by single click. Distributed login NukeViet support login by OpenID. Users can login to your website by accounts f-rom popular and well-known provider, such as Google, Yahoo or other OpenID providers. It help your website more accessible and reduce user&#039;s time to filling out registration forms. Download NukeViet 3.0: http://code.google.com/p/nuke-viet/downloads/list http://code.google.com/p/nuke-viet/downloads/list Website: http://nukeviet.vn/ http://nukeviet.vn');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_cat`
--

DROP TABLE IF EXISTS `nv3_en_news_cat`;
CREATE TABLE `nv3_en_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=15  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_cat`
--

INSERT INTO `nv3_en_news_cat` VALUES
(1, 0, 'Co-operate', '', 'Co-operate', '', '', '', 2, 5, 0, 'viewcat_page_new', 2, '2,3', 1, 3, '', '', 1277689708, 1277689708, 0, ''), 
(2, 1, 'Careers at NukeViet', '', 'Careers-at-NukeViet', '', '', '', 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690086, 1277690259, 0, ''), 
(3, 1, 'Partners', '', 'Partners', '', '', '', 2, 7, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690142, 1277690291, 0, ''), 
(4, 0, 'NukeViet news', '', 'NukeViet-news', '', '', '', 1, 1, 0, 'viewcat_page_new', 3, '5,6,7', 1, 3, '', '', 1277690451, 1277690451, 0, ''), 
(5, 4, 'Security issues', '', 'Security-issues', '', '', '', 1, 2, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690497, 1277690564, 0, ''), 
(6, 4, 'Release notes', '', 'Release-notes', '', '', '', 2, 3, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690588, 1277690588, 0, ''), 
(7, 4, 'Development team talk', '', 'Development-team-talk', '', '', '', 3, 4, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690652, 1277690652, 0, ''), 
(8, 0, 'NukeViet community', '', 'NukeViet-community', '', '', '', 3, 8, 0, 'viewcat_page_new', 3, '9,10,11', 1, 3, '', '', 1277690748, 1277690748, 0, ''), 
(9, 8, 'Activities', '', 'Activities', '', '', '', 1, 9, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690765, 1277690765, 0, ''), 
(10, 8, 'Events', '', 'Events', '', '', '', 2, 10, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690783, 1277690783, 0, ''), 
(11, 8, 'Faces of week &#x3A;D', '', 'Faces-of-week-D', '', '', '', 3, 11, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690821, 1277690821, 0, ''), 
(12, 0, 'Lastest technologies', '', 'Lastest-technologies', '', '', '', 4, 12, 0, 'viewcat_page_new', 2, '13,14', 1, 3, '', '', 1277690888, 1277690888, 0, ''), 
(13, 12, 'World wide web', '', 'World-wide-web', '', '', '', 1, 13, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690934, 1277690934, 0, ''), 
(14, 12, 'Around internet', '', 'Around-internet', '', '', '', 2, 14, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1277690982, 1277690982, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_comments`
--

DROP TABLE IF EXISTS `nv3_en_news_comments`;
CREATE TABLE `nv3_en_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_config_post`
--

DROP TABLE IF EXISTS `nv3_en_news_config_post`;
CREATE TABLE `nv3_en_news_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_rows`
--

DROP TABLE IF EXISTS `nv3_en_news_rows`;
CREATE TABLE `nv3_en_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_rows`
--

INSERT INTO `nv3_en_news_rows` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 2, 0, 0, 0, 'VINADES'), 
(2, 14, '14,8', 0, 8, '', 1, 1277691366, 1277691470, 1, 1277691360, 0, 2, 'What does WWW mean?', 'What-does-WWW-mean', 'The World Wide Web, abbreviated as WWW and commonly known as the Web, is a system of interlinked hypertext&nbsp; documents accessed via the Internet.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 0, 0, 0, 0, 'Web'), 
(3, 12, '12,7', 0, 8, '', 2, 1277691851, 1287160943, 1, 1277691840, 0, 2, 'HTML 5 review', 'HTML-5-review', 'I have to say that my money used to be on XHTML 2.0 eventually winning the battle for the next great web standard. Either that, or the two titans would continue to battle it out for the forseable future, leading to an increasingly fragmented web.', 'screenshot.jpg', '', 'thumb/screenshot.jpg|block/screenshot.jpg', 1, 2, 1, 2, 0, 0, 0, 'HTML5'), 
(4, 4, '4', 0, 1, 'VOVNews&#x002F;VNA', 0, 1292959020, 1292959513, 1, 1292959020, 0, 2, 'First open-source company starts operation', 'First-open-source-company-starts-operation', 'The Vietnam Open Source Development Joint Stock Company (VINADES.,JSC), the first firm operating in the field of open source in the country, made its debut on February 25.', 'nangly.jpg', '', 'thumb/nangly.jpg|thumb/nangly.jpg', 1, 2, 1, 1, 0, 0, 0, 'VINADES, Nguyen Anh Tu'), 
(5, 4, '4', 0, 1, '', 0, 1292959490, 1292959664, 1, 1292959440, 0, 2, 'NukeViet 3.0 - New CMS for News site', 'NukeViet-30-New-CMS-for-News-site', 'NukeViet 3.0 is a professional system: VINADES.,JSC founded to maintain and improve NukeViet 3.0 features. VINADES.,JSC co-operated with many professional hosting providers to test compatibility issues.', 'nukeviet3.jpg', '', 'thumb/nukeviet3.jpg|thumb/nukeviet3.jpg', 1, 2, 1, 1, 0, 0, 0, 'NukeViet, VINADES');


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_sources`
--

DROP TABLE IF EXISTS `nv3_en_news_sources`;
CREATE TABLE `nv3_en_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_news_sources`
--

INSERT INTO `nv3_en_news_sources` VALUES
(1, 'Wikipedia', 'http://www.wikipedia.org', '', 1, 1277691366, 1277691366), 
(2, 'Enlightened Website Development', 'http://www.etianen.com', '', 2, 1277691851, 1277691851);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_news_topics`
--

DROP TABLE IF EXISTS `nv3_en_news_topics`;
CREATE TABLE `nv3_en_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_referer_stats`
--

DROP TABLE IF EXISTS `nv3_en_referer_stats`;
CREATE TABLE `nv3_en_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_searchkeys`
--

DROP TABLE IF EXISTS `nv3_en_searchkeys`;
CREATE TABLE `nv3_en_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_en_voting`
--

DROP TABLE IF EXISTS `nv3_en_voting`;
CREATE TABLE `nv3_en_voting` (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_voting`
--

INSERT INTO `nv3_en_voting` VALUES
(2, 'Do you know about Nukeviet 3?', '', 1, 1, 0, '0', 1275318563, 0, 1), 
(3, 'What are you interested in open source', '', 1, 1, 0, '0', 1275318589, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_en_voting_rows`
--

DROP TABLE IF EXISTS `nv3_en_voting_rows`;
CREATE TABLE `nv3_en_voting_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_en_voting_rows`
--

INSERT INTO `nv3_en_voting_rows` VALUES
(5, 2, 'A whole new sourcecode for the web.', '', 0), 
(6, 2, 'Open source, free to use.', '', 0), 
(7, 2, 'Use of xHTML, CSS and Ajax support', '', 0), 
(8, 2, 'All the comments on', '', 0), 
(9, 3, 'constantly improved, modified by the whole world.', '', 0), 
(10, 3, 'To use the free of charge.', '', 0), 
(11, 3, 'The freedom to explore, modify at will.', '', 0), 
(12, 3, 'Match to learning and research because the freedom to modify at will.', '', 0), 
(13, 3, 'All comments on', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_groups`
--

DROP TABLE IF EXISTS `nv3_groups`;
CREATE TABLE `nv3_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_ipcountry`
--

DROP TABLE IF EXISTS `nv3_ipcountry`;
CREATE TABLE `nv3_ipcountry` (
  `ip_from` int(11) unsigned NOT NULL,
  `ip_to` int(11) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `ip_file` smallint(5) unsigned NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `ip_from` (`ip_from`,`ip_to`),
  KEY `ip_file` (`ip_file`),
  KEY `country` (`country`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_ipcountry`
--

INSERT INTO `nv3_ipcountry` VALUES
(2130706432, 2130771967, 'ZZ', 127, 1457088513);


-- ---------------------------------------


--
-- Table structure for table `nv3_language`
--

DROP TABLE IF EXISTS `nv3_language`;
CREATE TABLE `nv3_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_language_file`
--

DROP TABLE IF EXISTS `nv3_language_file`;
CREATE TABLE `nv3_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_logs`
--

DROP TABLE IF EXISTS `nv3_logs`;
CREATE TABLE `nv3_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_sessions`
--

DROP TABLE IF EXISTS `nv3_sessions`;
CREATE TABLE `nv3_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_setup`
--

DROP TABLE IF EXISTS `nv3_setup`;
CREATE TABLE `nv3_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_setup_language`
--

DROP TABLE IF EXISTS `nv3_setup_language`;
CREATE TABLE `nv3_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_language`
--

INSERT INTO `nv3_setup_language` VALUES
('en', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_setup_modules`
--

DROP TABLE IF EXISTS `nv3_setup_modules`;
CREATE TABLE `nv3_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `module_file` varchar(50) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_modules`
--

INSERT INTO `nv3_setup_modules` VALUES
('about', 0, 1, 'about', 'about', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('banners', 1, 0, 'banners', 'banners', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('contact', 0, 1, 'contact', 'contact', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('news', 0, 1, 'news', 'news', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('voting', 0, 0, 'voting', 'voting', '3.1.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('forum', 0, 0, 'forum', 'forum', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('search', 1, 0, 'search', 'search', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('users', 1, 0, 'users', 'users', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('download', 0, 1, 'download', 'download', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('statistics', 0, 0, 'statistics', 'statistics', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('faq', 0, 1, 'faq', 'faq', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('menu', 0, 1, 'menu', 'menu', '3.1.00 1273225635', 1457088459, 'VINADES (contact@vinades.vn)', ''), 
('rss', 1, 0, 'rss', 'rss', '3.0.01 1287532800', 1457088459, 'VINADES (contact@vinades.vn)', '');


-- ---------------------------------------


--
-- Table structure for table `nv3_users`
--

DROP TABLE IF EXISTS `nv3_users`;
CREATE TABLE `nv3_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `website` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(40) NOT NULL DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL DEFAULT '',
  `last_agent` varchar(255) NOT NULL DEFAULT '',
  `last_openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users`
--

INSERT INTO `nv3_users` VALUES
(1, 'tungfpm', 'eb24c726d4bcfe7f3490091c032004d6', '5ca484c24d09a46e90130e2a40c8a62b88b45dbf', 'tungfpm@outlook.com', 'tungfpm', '', '', 0, NULL, 1457088510, '', '', '', '', '', '', 'What is your favorite food?', 'rice', '', 0, 1, '', 1, '', 1457088510, '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv3_users_config`
--

DROP TABLE IF EXISTS `nv3_users_config`;
CREATE TABLE `nv3_users_config` (
  `config` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_config`
--

INSERT INTO `nv3_users_config` VALUES
('registertype', '1', 1457088459), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1457088459), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1457088459), 
('siteterms_en', '<p style=\"text-align:center;\"> <strong>Website usage terms and conditions – sample template</strong></p><p> Welcome to our website. If you continue to browse and use this website you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern [business name]’s relationship with you in relation to this website.<br  /> The term ‘[business name]’ or ‘us’ or ‘we’ refers to the owner of the website whose registered office is [address]. Our company registration number is [company registration number and place of registration]. The term ‘you’ refers to the user or viewer of our website.<br  /> The use of this website is subject to the following terms of use:<br  /> • The content of the pages of this website is for your general information and use only. It is subject to change without notice.<br  /> • Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.<br  /> • Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.<br  /> • This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.<br  /> • All trademarks reproduced in this website, which are not the property of, or licensed to the operator, are acknowledged on the website.<br  /> • Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.<br  /> • fr0m time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).<br  /> • You may not crea-te a link to this website fr0m another website or document without [business name]’s prior written consent.<br  /> • Your use of this website and any dispute arising out of such use of the website is subject to the laws of England, Scotland and Wales.</p>', 1274757617);


-- ---------------------------------------


--
-- Table structure for table `nv3_users_openid`
--

DROP TABLE IF EXISTS `nv3_users_openid`;
CREATE TABLE `nv3_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_users_question`
--

DROP TABLE IF EXISTS `nv3_users_question`;
CREATE TABLE `nv3_users_question` (
  `qid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_question`
--

INSERT INTO `nv3_users_question` VALUES
(1, 'What is the first name of your favorite uncle?', 'en', 1, 1274841115, 1274841115), 
(2, 'whe-re did you meet your spouse', 'en', 2, 1274841123, 1274841123), 
(3, 'What is your oldest cousin&#039;s name?', 'en', 3, 1274841131, 1274841131), 
(4, 'What is your youngest child&#039;s username?', 'en', 4, 1274841142, 1274841142), 
(5, 'What is your oldest child&#039;s username?', 'en', 5, 1274841150, 1274841150), 
(6, 'What is the first name of your oldest niece?', 'en', 6, 1274841158, 1274841158), 
(7, 'What is the first name of your oldest nephew?', 'en', 7, 1274841167, 1274841167), 
(8, 'What is the first name of your favorite aunt?', 'en', 8, 1274841175, 1274841175), 
(9, 'whe-re did you spend your honeymoon?', 'en', 9, 1274841183, 1274841183);


-- ---------------------------------------


--
-- Table structure for table `nv3_users_reg`
--

DROP TABLE IF EXISTS `nv3_users_reg`;
CREATE TABLE `nv3_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;